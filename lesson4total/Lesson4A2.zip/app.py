import math
import sys

from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
from matplotlib.figure import Figure
from PySide6.QtWidgets import (
    QApplication,
    QHBoxLayout,
    QMainWindow,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)


class DataWindow(QMainWindow):
    MAX_ROWS = 100
    VISIBLE_ROWS = 10

    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("Data Viewer")

        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        main_layout = QHBoxLayout(central_widget)
        data_layout = QVBoxLayout()
        main_layout.addLayout(data_layout)

        self.load_button = QPushButton("Load Data")
        self.load_button.clicked.connect(self.load_data)
        data_layout.addWidget(self.load_button)

        self.table = QTableWidget(self.MAX_ROWS, 2)
        self.table.setHorizontalHeaderLabels(["X", "Y"])
        self.table.verticalHeader().setDefaultSectionSize(25)
        self.table.setFixedHeight(
            self.VISIBLE_ROWS * self.table.verticalHeader().defaultSectionSize()
            + self.table.horizontalHeader().height()
            + 2 * self.table.frameWidth()
        )
        data_layout.addWidget(self.table)

        self.figure = Figure()
        self.canvas = FigureCanvasQTAgg(self.figure)
        self.axes = self.figure.add_subplot(111)
        main_layout.addWidget(self.canvas, stretch=1)

        self.draw_sine_wave()

    def load_data(self) -> None:
        pass

    def set_data(self, x_values: list[float], y_values: list[float]) -> None:
        if len(x_values) != len(y_values):
            raise ValueError("X and Y data must have the same number of values.")
        if len(x_values) > self.MAX_ROWS:
            raise ValueError(f"Data cannot exceed {self.MAX_ROWS} rows.")

        self.table.clearContents()
        for row, (x_value, y_value) in enumerate(zip(x_values, y_values)):
            self.table.setItem(row, 0, QTableWidgetItem(str(x_value)))
            self.table.setItem(row, 1, QTableWidgetItem(str(y_value)))

    def draw_sine_wave(self) -> None:
        x_values = [index * 0.1 for index in range(100)]
        y_values = [math.sin(value) for value in x_values]

        self.axes.clear()
        self.axes.plot(x_values, y_values)
        self.axes.set_xlabel("X")
        self.axes.set_ylabel("Y")
        self.axes.set_title("Sine Wave")
        self.canvas.draw()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = DataWindow()
    window.show()
    sys.exit(app.exec())
